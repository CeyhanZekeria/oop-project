
/**
 * Главен клас за стартиране на приложението.
 */
public class Application {

    /**
     * Основен входен метод на програмата.
     * Стартира интерфейса на склада.
     */
    public static void main(String[] args) {
        WarehouseCLI.start();
    }
}
//chcp 65001
//javac *.java
//java Application.java